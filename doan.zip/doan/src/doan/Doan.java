/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package doan;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author ASUS
 */
public class Doan {

    /**
     * @param args the command line arguments
     */
     
    public static void main(String[] args) {
        ArrayList<MonHoc> danhSachMonHoc = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- QUẢN LÝ MÔN HỌC ---");
            System.out.println("1. Thêm môn học");
            System.out.println("2. Hiển thị danh sách môn học");
            System.out.println("3. Đăng ký sinh viên vào môn học");
            System.out.println("4. Thoát");
            System.out.print("Chọn chức năng: ");
            int luaChon = scanner.nextInt();
            scanner.nextLine(); // Xóa bỏ dòng thừa

            switch (luaChon) {
                case 1:
                    System.out.println("\nNhập thông tin môn học:");
                    String maMonHoc;
                    do {
                        System.out.print("Mã môn học (không được để trống): ");
                        maMonHoc = scanner.nextLine();
                        if (maMonHoc.isEmpty()) {
                            System.out.println("Mã môn học không được để trống. Vui lòng nhập lại.");
                        }
                    } while (maMonHoc.isEmpty());

                    System.out.print("Tên môn học: ");
                    String tenMonHoc = scanner.nextLine();
                    System.out.print("Số tín chỉ: ");
                    int soTinChi = scanner.nextInt();
                    scanner.nextLine(); // Xóa dòng thừa
                    System.out.print("Giảng viên: ");
                    String giangVien = scanner.nextLine();
                    System.out.print("Số lượng tối đa: ");
                    int soLuongToiDa = scanner.nextInt();

                    MonHoc monHoc = new MonHoc(maMonHoc, tenMonHoc, soTinChi, giangVien, soLuongToiDa);
                    danhSachMonHoc.add(monHoc);
                    System.out.println("Đã thêm môn học thành công!");
                    break;

                case 2:
                    System.out.println("\n--- DANH SÁCH MÔN HỌC ---");
                    if (danhSachMonHoc.isEmpty()) {
                        System.out.println("Danh sách trống.");
                    } else {
                        for (MonHoc mh : danhSachMonHoc) {
                            mh.hienThiThongTinMonHoc();
                            System.out.println("--------------------");
                        }
                    }
                    break;

                case 3:
                    System.out.print("Nhập mã môn học muốn đăng ký: ");
                    String maTimKiem = scanner.nextLine();
                    boolean timThay = false;

                    for (MonHoc mh : danhSachMonHoc) {
                        if (mh.getMaMonHoc().equals(maTimKiem)) {
                            timThay = true;
                            if (mh.dangKySinhVien()) {
                                System.out.println("Đăng ký thành công!");
                            } else {
                                System.out.println("Lớp đã đầy. Không thể đăng ký.");
                            }
                            break;
                        }
                    }

                    if (!timThay) {
                        System.out.println("Không tìm thấy môn học với mã: " + maTimKiem);
                    }
                    break;

                case 4:
                    System.out.println("Chương trình kết thúc. Tạm biệt!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
            }
        }
    }
}


   

